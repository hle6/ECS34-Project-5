#ifndef CSVREADER_H 	  			 	 
#define CSVREADER_H

#include <istream>
#include <string>
#include <vector>
#include <csv.h>
#include <iostream>
#include <queue>

class CCSVReader{
    protected:
        static void callback_row(void *str, size_t length, void *calldata);
        static void callback_end(int constant, void *calldata);
        std::queue<std::vector<std::string>> buffer;
        //stack
        std::istream &In;
        struct csv_parser csvparser;
        std::vector<std::string> csvrow;

         
    public:
        CCSVReader(std::istream &in);
        ~CCSVReader();
        
        bool End() const;
        bool ReadRow(std::vector< std::string > &row);
};

#endif
