#ifndef XMLREADER_H
#define XMLREADER_H

#include "XMLEntity.h"
#include <istream>
#include <expat.h>
#include <queue>

class CXMLReader{
    private:
        static void callback_start(void *calldata, const char *name, const char **attributs);
        static void callback_end(void *calldata, const char *name);
        static void callback_text(void *calldata, const char *s, int len);
        std::istream &Is;
        std::queue<SXMLEntity> buffer;
        SXMLEntity xmlentity;
        XML_Parser xmlparser = XML_ParserCreate(NULL); //parser is created by this function
        
        
    public:
        CXMLReader(std::istream &is);
        ~CXMLReader();
        
        bool End();
        bool ReadEntity(SXMLEntity &entity, bool skipcdata = false);
};

#endif
