#include "StringUtils.h" 	  			 	 
#include <algorithm> 
#include <cctype>
#include <cstdio>
#include <string.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include<bits/stdc++.h> 


namespace StringUtils{
    
std::string Slice(const std::string &str, ssize_t start, ssize_t end){
    // Your code goes here

size_t indexWidth = str.length();

if(start<0){
    start= start+indexWidth;
}
if(end<0){
    if(start<0){
        end=indexWidth+end-start;
    }
    else{
        end= indexWidth+end-start;
}
}
if(end==0){
    end=indexWidth-start;
}
if(end>indexWidth){
   end = indexWidth-start;
}
if(start>indexWidth){
    return "";
}
if(start+end>indexWidth){
    end=indexWidth-start;
}

std::string resultstring="";
     resultstring.assign(str.substr(start,end));
      return resultstring;
}
std::string getString(char x) 
{ 
    // string class has a constructor 
    // that allows us to specify size of 
    // string as first parameter and character 
    // to be filled in given size as second 
    // parameter. 
    //https://www.geeksforgeeks.org/how-to-convert-a-single-character-to-string-in-cpp/
    std::string s(1, x); 
  
    return s;    
} 


std::string Capitalize(const std::string &str){
    // Your code goes here
    std::string str2="";
    str2.assign(str);
          // std::string str3="";

   // str2.append(str);
    size_t length = str2.length();
   
  if(isupper(str2[0])){
    for(size_t i=1;i<length;i++){
        str2[i]=tolower(str2[i]);
    }
    return str2;
}
if(islower(str2[0])&&(!isblank(str2[0]))){
     str2[0]=toupper(str2[0]);
    for(size_t i=1;i<length;i++){
        str2[i]=tolower(str2[i]);
    }
    return str2;
}
else{
      for(size_t i=0;i<length;i++){
        str2[i]=tolower(str2[i]);
    }
    return str2;
}

   

 return str2;
}

std::string Title(const std::string &str){
   
   std::string str2="";
      
  str2.assign(Capitalize(str));
     size_t length = str2.length();
     size_t cursor=1;
     while(cursor<length){
        if(!isalpha(str2[cursor-1])){
            str2[cursor]=toupper(str2[cursor]);
        }

         if(!isblank(str2[cursor])){
             if(isblank(str2[cursor-1])){
                str2[cursor]=toupper(str2[cursor]);
             }
         }
         cursor++;
     }
return str2;
 
}

std::string LStrip(const std::string &str){
    // Your code goes here

    std::string str2="";
      std::     string str3="";
      ssize_t length = str.length();

  str2.assign(str);
     int cursor=0;
     while(isspace(str2[0])){
         str2.erase(0,1);
     }
         
    return str2;

}

std::string RStrip(const std::string &str){
    //Your code goes here
       std::string str2="";
      std::     string str3="";
      ssize_t length = str.length();

  str2.assign(str);
     int cursor=length-1;
     while(isspace(str2[cursor])){
         str2.erase(cursor,1);
         cursor--;
     }
         
    return str2;

}

std::string Strip(const std::string &str){
    //Your code goes here
   std::string str2="";
      std::     string str3="";
     str2.assign(str);
     str3.assign(LStrip(str2));
          str3.assign(RStrip(str3));
          return str3;

} 
std::string Center(const std::string &str, int width, char fill){
     std::string str2="";
      std::     string str3="";
      std:: string str4= "";
      width = width-str.length();
        str2.assign(str);
        int leftwid= width/2;
        int rightwid= width-leftwid;
        str3.assign(LJust(str2,rightwid+str.length(),fill));
     while(leftwid>0){
         str4.append(getString(fill));
         leftwid--;
     }
     str4.append(str3);
    return str4;

}

std::string LJust(const std::string &str, int width, char fill){
  
   std::string str2="";
      std::     string str3="";
       width = width-str.length();
  str2.assign(str);
       while(width!=0){
        str2.append(getString(fill));
        width--;
    }
    return str2;
}

std::string RJust(const std::string &str, int width, char fill){
   std::string str2="";
      std::     string str3="";
       width = width-str.length();
  str2.assign(str);
       while(width!=0){
        str3.append(getString(fill));
        width--;
    }
    str3.append(str2);
    return str3;
   
}

std::string Replace(const std::string &str, const std::string &old, const std::string &rep){
     std::string original="";
      std::string target="";
       std::string toreplace="";
      original.assign(str);
      target.assign(old);
      toreplace.assign(rep);
       size_t found=original.find(target);

    while(found!=std::string::npos){
        original.replace(found,target.length(),toreplace);
         found=original.find(target,found+1);
    }
  return original;
}
std::string DividetoCon(const std::string &str, const std::string &splt){
       std::string toSplit="";
      std::string splitter="";
      std::string resultstring="";
     toSplit.assign(str);
     splitter.assign(splt);
     
       size_t found=toSplit.find(splitter);
       resultstring.assign(toSplit.substr(0,found));
       return resultstring;
}
 std::vector< std::string > SplitforWhite(const std::string &str){
     
    
    
             std:: vector<std::string> theList;
std::string string1="";
     string1.assign(str);
 for(size_t i=0;i<string1.length()-1;i++){
         if(!isspace(string1[i])){
                      size_t cursor=i;

             while((!isspace(string1[cursor])&&(cursor<string1.length()))){
                 cursor++;
             }
                    theList.push_back(string1.substr(i,cursor-i));
            i = cursor;
         }
         else{
             continue;
         }
     }
      
    return theList ; 
        
}
std::vector< std::string > Split(const std::string &str, const std::string &splt){

    
            std:: vector<std::string> theList;

       std::string toSplit="";
      std::string splitter="";
      std::string resultstring="";
     toSplit.assign(str);
     splitter.assign(splt);
     if(splitter.empty()){
        return SplitforWhite(str);
     }
       size_t found=toSplit.find(splitter);
       while(found!=std::string::npos){
        //   if(!DividetoCon(toSplit,splitter).empty()){
           theList.push_back(DividetoCon(toSplit,splitter));
    //   }
           // toSplit.assign(Slice(toSplit,found+splitter.length(),toSplit.length()-1));
           toSplit.assign(toSplit.substr(found+splitter.length(),toSplit.length()-1));
           found=toSplit.find(splitter);
       }
       theList.push_back(toSplit);
     return theList;

}


std::string Join(const std::string &str, const std::vector< std::string > &vect){
    // Your code goes here
   std::string str1="";
    str1.assign(str);
    std::string str2="";
    str2.append(vect[0]);
    for(int i=1;i<vect.size();i++){
            str2.append(str1);
            str2.append(vect[i]);

    }
       return str2;
       

}

std::string ExpandTabs(const std::string &str, int tabsize){
    // Your code goes here
    //    if(tabsize==0){
    //     tabsize=4;
    // }
    size_t size = tabsize;
        std:: string string1 ="";
    std:: string string2 ="";
        std:: string string3 ="";
      string1.assign(str);
      std::vector<std::string> v= Split(string1,"\t");
      for(int i=0;i<v.size()-1;i++){
        if(v[i].length()==size){
            int k =v[i].length()+size;
            while(v[i].length()<k){
                v[i].append(" ");
            }
        }
        else if(v[i].length()>size){
            int k= 2*size -v[i].length();
            while(k>0){
                v[i].append(" ");
                k--;

            }
        }
        else{
            while(v[i].length()<size){
                v[i].append(" ");
            }
        }
        string2.append(v[i]);
      }
  string2.append(v[v.size()-1]);
      return string2;
      
}
//https://www.geeksforgeeks.org/edit-distance-dp-5/
int min(int x, int y, int z) 
{ 
   return std::min(std::min(x, y), z); 
} 
int editDist(std::string str1 , std::string str2 , int m ,int n) 
{ 
    // If first string is empty, the only option is to 
    //https://www.geeksforgeeks.org/edit-distance-dp-5/
    // insert all characters of second string into first 
    if (m == 0) return n; 
  
    // If second string is empty, the only option is to 
    // remove all characters of first string 
    if (n == 0) return m; 
  
    // If last characters of two strings are same, nothing 
    // much to do. Ignore last characters and get count for 
    // remaining strings. 
    if (str1[m-1] == str2[n-1]) 
        return editDist(str1, str2, m-1, n-1); 
  
    // If last characters are not same, consider all three 
    // operations on last character of first string, recursively 
    // compute minimum cost for all three operations and take 
    // minimum of three values. 
    return 1 + min ( editDist(str1,  str2, m, n-1),    // Insert 
                     editDist(str1,  str2, m-1, n),   // Remove 
                     editDist(str1,  str2, m-1, n-1) // Replace 
                   ); 
} 
//https://www.geeksforgeeks.org/edit-distance-dp-5/
int EditDistance(const std::string &left, const std::string &right, bool ignorecase){

    std::string str1="";
    std::string str2="";
    str1.assign(left);
    str2.assign(right);
    int m= str1.length();
    int n= str2.length();
    if(ignorecase){
       
      for(int i=0;i<m;i++){
        str1[i]=tolower(str1[i]);
      }
      for(int i=0;i<n;i++){
        str2[i]=tolower(str2[i]);
      }
    }
    return editDist(str1,str2,m,n); 

}
    }